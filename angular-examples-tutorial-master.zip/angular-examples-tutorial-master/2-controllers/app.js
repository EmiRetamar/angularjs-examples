var app = angular.module('app', []);
app.controller('SimpleCtrl', [function() {
  this.texto = "AngularJS";
}]);
