angular.module('app', ['principal', 'climamod']);

angular.module('climamod', []);
angular.module('principal', []);
