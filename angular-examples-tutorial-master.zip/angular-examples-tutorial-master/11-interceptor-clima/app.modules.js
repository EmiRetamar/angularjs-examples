angular.module('app', ['principal', 'climamod', 'LocalStorageModule']);

angular.module('climamod', []);
angular.module('principal', []);
