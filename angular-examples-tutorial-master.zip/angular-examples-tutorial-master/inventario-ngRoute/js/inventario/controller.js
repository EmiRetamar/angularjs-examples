angular.module('myapp.inventario')
.controller('InventarioCtrl', ['$scope', function($scope){
	$scope.saludo = 'Hola a Todos!';
}])